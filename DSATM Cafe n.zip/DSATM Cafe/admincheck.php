

<?php
$connection = mysqli_connect("localhost", "root", "", "cart");
$query = "SELECT * FROM admin";
$query_run = mysqli_query($connection, $query);

//session_start();

/*$username = filter_input(INPUT_POST, 'adminU');
$password = filter_input(INPUT_POST, 'adminP');
*/
$conn = "";
  
try {
    $servername = "localhost";
    $dbname = "cart";
    $username = "root";
    $password = "";
  
    $conn = new PDO(
        "mysql:host=$servername; dbname=cart",
        $username, $password
    );
     
   $conn->setAttribute(PDO::ATTR_ERRMODE,
                    PDO::ERRMODE_EXCEPTION);
}
catch(PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}
 
// Create connection
session_start();

function test_input($data) {
     
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

if ($_SERVER["REQUEST_METHOD"]== "POST") {
     
    $username = test_input($_POST["adminU"]);
    $password = test_input($_POST["adminP"]);
    $stmt = $conn->prepare("SELECT * FROM admin");
    $stmt->execute();
    $users = $stmt->fetchAll();
     
    foreach($users as $user) {
         
        if(($user["username"] == $username) && 
            ($user['password'] == $password)) {
                header("location: admin/register.php");
        }
        else {
            echo "alert('WRONG INFORMATION')";
            echo "</script>";
            die();
        }
    }
}

/*$_SESSION['adminU'] = "admin";
$_SESSION['adminP'] = "admin";
header("location: admin/register.php");
*/
mysqli_close($conn);
