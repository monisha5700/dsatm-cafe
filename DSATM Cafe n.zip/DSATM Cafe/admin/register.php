<?php
include('includes/header.php');
?>

<div class="modal fade" id="addadminprofile" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Add Data</h5>
                <button onclick="myFunction()">Go to login page</button>

				<script>
					function myFunction() {
  						location.replace("http://localhost/DSATM%20Cafe/register.php")
					}
				</script>

            </div>
            <p></p>
            <form action="connect.php" method="POST">

                <div class="modal-body">

                    <div class="form-group">
                        <label> Name </label>
                        <input type="text" class="form-control" placeholder="Name" name="nname">
                    </div>
                    <div class="form-group">
                        <label>Username</label>
                        <input type="text" class="form-control" placeholder="Username" name="uname">
                    </div>
                    <div class="form-group">
                        <label>Email</label>
                        <input type="email" class="form-control" placeholder="Email" name="ename">
                    </div>
                    <div class="form-group">
                        <label>Password</label>
                        <input type="password" class="form-control" placeholder="Password" name="pname">
                    </div>
                    <div class="form-group">
                        <label>Status</label>
                        <input type="text"  class="form-control" placeholder="Enter status" name="sname">
                    </div>

                </div>
                <div class="modal-footer">
                	<p></p>
                    <button type="submit" name="registerbtn" class="btn btn-primary">Save</button>
                </div>
            </form>

        </div>
    </div>
</div>


<div class="container-fluid">

    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <a href="register.php">
                <h6 class="m-0 font-weight-bold text-primary">Admin Profile </h6>
            </a>
            <a href="menu.php">
                <h6 class="m-0 font-weight-bold text-primary">Menu</h6>
            </a>

            <a href="./../index.php" class="">
                <h6 class="m-0 font-weight-bold text-primary">
                    DSATM Cafe</h6>
            </a>
        
            </h6>
        </div>

        <div class="card-body">

            <div class="table-responsive">
                <?php
                $connection = mysqli_connect("localhost", "root", "", "cart");
                $query = "SELECT * FROM registration";
                $query_run = mysqli_query($connection, $query);

                ?>
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Name </th>
                            <th>Username </th>
                            <th>Email </th>
                            <th>Password</th>
                            <th>Update</th>
                            <th>Reset</th>
                            <th>Status</th>
                            <th>DELETE </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if (mysqli_num_rows($query_run) > 0) {
                            while ($row = mysqli_fetch_assoc($query_run)) {
                                ?>
                                <tr>

                                    <td style="text-align: center;">  <?php echo $row['name']; ?></td>
                                    <td style="text-align: center;">  <?php echo $row['username']; ?></td>
                                    <td style="text-align: center;" >  <?php echo $row['email']; ?></td>
                                    <td style="text-align: center;">  <?php echo $row['password']; ?> </td>
                                    <td style="text-align: center;">  
                                        <form action="status.php" method="post">
                                            <input type="hidden" name="status_name" value="<?php echo $row['name']; ?>">
                                            <button type="submit" name="status_btn" class="btn btn-danger">Done</button>
                                        </form>
                                    
                                    <td style="text-align: center;">
                                        <form action="reset.php" method="post">
                                            <input type="hidden" name="reset_name" value="<?php echo $row['name']; ?>">
                                            <button type="submit" name="reset_btn" class="btn btn-danger">Reset</button>
                                        </form>
                                    <td style="text-align: center;">  <?php echo $row['status']; ?> </td>

                                    <td style="text-align: center;"> 
                                        <form action="delete.php" method="post">
                                            <input type="hidden" name="delete_name" value="<?php echo $row['name']; ?>">
                                            <button type="submit" name="delete_btn" class="btn btn-danger"> DELETE</button>
                                        </form>
                                    </td>
                                </tr>
                        <?php
                            }
                        } else {
                            echo "No Record Found";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php
include('includes/scripts.php');
?>