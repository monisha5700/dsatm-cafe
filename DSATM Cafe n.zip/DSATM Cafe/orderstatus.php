<html>

<head>
    <title>Login Page</title>
    <link rel="icon" href="assets/imgs/logo.png" />
    <link rel="stylesheet" type="text/css" href="himanshu.css">
    <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>
<body>
<div class="col-md-4 register-right offset = md-3">
                        <h2>Login Here</h2>
                        <form action="orderstatus1.php" method="post">
                            <div class="register-form">

                                <div class="form-group">
                                    <input type="text" class="form-control" placeholder="Username" name="uuname">
                                </div>

                                <div class="form-group">
                                    <input type="password" class="form-control" placeholder="Password" name="ppname">
                                </div>

                                <input type="submit" value="Login" class="btn btn-primary" name="submit">

                            </div>
                        </form>
</div>
</body>