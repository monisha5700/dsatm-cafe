<?php
include('includes/header.php');
?>

<html lang="en">

<head>
    <link rel="icon" href="assets/imgs/logo.png" />

    <link rel="stylesheet" type="text/css" href="lastpage.css">
    <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <title>Admin Login</title>
    <style>
    	.bg-body {
            background-image: linear-gradient(to left, #4d90a3, #74bacf);
        }
    </style>

</head>
<body class="bg-body">
    <div class="container">
        <form class="well form-horizontal" action="register.php" method="post" id="contact_form">
            <fieldset>
                </br>
                </br>
                </br>
                </br>
                </br>
                <h2>Admin Login</h2>
            </fieldset>
        </form>

    </div>

</body>

</html>
<tbody>
	<?php
		session_start();
		$connect = mysqli_connect("localhost", "root", "", "cart");
        if (mysqli_num_rows($query_run) > 0) {
             while ($row = mysqli_fetch_assoc($query_run)) {
    ?>
    <tr>
		<td style="text-align: center;">  <?php echo $row['name']; ?></td>
    	<td style="text-align: center;">  <?php echo $row['username']; ?></td>
    	<td style="text-align: center;" >  <?php echo $row['email']; ?></td>
    </tr>
<?php
}
} else {
    echo "No Record Found";
}
?>
</tbody>
<?php
include('includes/scripts.php');
?>